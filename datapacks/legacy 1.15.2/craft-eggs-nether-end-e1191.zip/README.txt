[[[[[[Thanks for downloading]]]]]]

INSTRUCTIONS
	1. Unzip this folder.
	2. Move the craft_eggs_nether_end folder to "saves" in Minecraft.
	3. Move it into the world of your choice.
	4. Open the world.
	5. Type /datapack list into the chat if cheats are on.
	6. You should see the datapack pop up.
	7. To make sure, type /recipe give and look for a spawn egg's recipe.
	8. Enjoy your world!