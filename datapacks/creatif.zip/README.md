# Creatif + V1.0

## fr-FR

  Un datapack simple, mais il fallait y penser.
  Qui permet l'accès à des blocs inaccessibles en créatif sans avoir a recourir a des commandes.

    * ajoute: barrier, commande block, debbug stick, jigsaw, knowledge book, spawner, structure block, structure void.

## en-EN


A simple datapack, but you had to think about it.
Which allows access to blocks inaccessible in creative without having to resort to commands.

   * add: barrier, commande block, debbug stick, jigsaw, knowledge book, spawner, structure block, structure void.

   @yhne
